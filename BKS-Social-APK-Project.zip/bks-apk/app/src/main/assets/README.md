# BKS Social

Termux/Android-friendly version. Uses a JSON file database instead of better-sqlite3, so it does not require native SQLite compilation.

## Run
```bash
npm install
npm start
```
Open http://127.0.0.1:3000 in your browser.

For production hosting, use a proper database and object storage; this JSON database is intended for local/demo development.
