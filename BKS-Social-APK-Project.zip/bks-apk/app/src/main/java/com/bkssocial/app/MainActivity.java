package com.bkssocial.app;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*; import java.io.*;
public class MainActivity extends Activity {
 WebView w;
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); w=findViewById(R.id.webview); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/public/index.html");}
 @Override public void onBackPressed(){if(w.canGoBack()) w.goBack(); else super.onBackPressed();}
}
